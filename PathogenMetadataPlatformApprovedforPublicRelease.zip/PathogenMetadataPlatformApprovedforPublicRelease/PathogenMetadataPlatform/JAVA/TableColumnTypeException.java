package biosampleparser;

/**
 *
 * @author WCHANG
 */
public class TableColumnTypeException extends Exception {
    
}
